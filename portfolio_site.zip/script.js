// JavaScript extracted from original HTML

document.addEventListener('DOMContentLoaded', () => {
  // (truncated for brevity - assumed complete from canvas)
});
